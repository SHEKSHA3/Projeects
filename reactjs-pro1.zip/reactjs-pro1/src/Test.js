import React from 'react'
import Text from './Text'

const Test = () => {
  return (
    <div>
        <p>
            <Text name = "Test"></Text>
        </p>
    </div>
  )
}

export default Test