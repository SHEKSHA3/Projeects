import React from 'react'

const Text = ({name}) => {
  return (
    <div>
        {name}
    </div>
  )
}

export default Text